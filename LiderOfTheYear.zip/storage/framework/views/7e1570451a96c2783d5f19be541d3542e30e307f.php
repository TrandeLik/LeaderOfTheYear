<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>События</h1>
                <div class='card'>
                    <div class='card-body'>
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <div name="categoryDiv">
                                <select name="category" onchange="writeTypes();">
                                    <option disabled selected>Категория</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->category == $thisType->category): ?>
                                            <option selected><?php echo e($category->category); ?></option>
                                        <?php else: ?>
                                            <option><?php echo e($category->category); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="button" name="category" onclick="changeInput('category');" value="Добавить">
                            </div>
                            <div name="typeDiv">
                                <select name="type" disabled>
                                    <option disabled selected>Тип события</option>
                                </select>
                                <input type="button" name="type" onclick="changeInput('type');" value="Добавить">
                            </div><br>
                            <div name="stageDiv">
                                <select name="stage" class="form-control">
                                    <option disabled selected>Этап</option>
                                    <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($stage->stage  == $thisType->stage): ?>
                                            <option selected><?php echo e($stage->stage); ?></option>
                                        <?php else: ?>
                                            <option><?php echo e($stage->stage); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="button" name="stage" onclick="changeInput('stage');" value="Добавить">
                            </div><br>
                            <div name="resultDiv">
                                <select name="result" class="form-control">
                                    <option disabled selected>Результат</option>
                                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($result->result  == $thisType->result): ?>
                                            <option selected><?php echo e($result->result); ?></option>
                                        <?php else: ?>
                                            <option><?php echo e($result->result); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="button" name="result" onclick="changeInput('result');" value="Изменить">
                            </div><br>
                            <input type="number" name="score" placeholder="Кол-во баллов" class="form-control" value="<?php echo e($thisType->score); ?>"><br>
                            <input type="submit" value="Отправить" class="btn btn-primary">
                        </form>
                        <div name="unused" style="display:none;">
                            <input type='text' name="category" placeholder="Категория" class="form-control">
                            <input type='text' name="type" placeholder="Тип события" class="form-control">
                            <input type='text' name="stage" placeholder="Этап" class="form-control">
                            <input type='text' name="result" placeholder="Результат" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="<?php echo e(url('/')); ?>"><button class="btn btn-primary" style="float: right">Назад</button></a>
    <script>
        let achievements = [];
        <?php $__currentLoopData = $achievementTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievementType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            achievements.push({category: "<?php echo e($achievementType->category); ?>", type: "<?php echo e($achievementType->type); ?>", stage: "<?php echo e($achievementType->stage); ?>", result: "<?php echo e($achievementType->result); ?>"});
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
    <script src="../../../public/js/achievementSelection.js"></script>
    <script>
        function writeTypes(){
            changeCategory();
            document.getElementsByName('type')[0].disabled = false;
        }

        function changeInput(name){
            let elements = document.getElementsByName(name);
            let parent = document.getElementsByName(name+'Div')[0];
            let el = parent.replaceChild(elements[2],elements[0]);
            document.getElementsByName('unused')[0].appendChild(el);
            if (elements[1].value == 'Добавить'){
                elements[1].value = 'Выбрать';
            } else {
                elements[1].value = 'Добавить';
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/editAchievementType.blade.php ENDPATH**/ ?>