<style>
    .btn-success{
        margin-top: 20px;
    }
    
    .btn-primary{
        float:right;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
            <div class="col-md-10">
            <div class="card border-success">
                <div class="card-header">Добавление<a href="/user"><button class="btn btn-primary">Отмена</button></a></div>
                <creating-achievement
                        :isUploadingConfirmationsPossible="<?php echo e(json_encode($isUploadingConfirmationsPossible)); ?>"
                        :categories="<?php echo e(json_encode($categories)); ?>"
                        :areCommentsWorking="<?php echo e(json_encode($areCommentsWorking)); ?>"
                        :achievementTypes="<?php echo e(json_encode($achievement_types)); ?>"
                        :action="'/achievement/add/new'">
                </creating-achievement>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/user/addAchievement.blade.php ENDPATH**/ ?>