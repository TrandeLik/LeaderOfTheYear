<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7 col-12">
            <h1 class="display-5">Ошибка :(</h1>
            <hr class="my-4">
            <p class="lead"><?php echo e($error); ?></p>
            <?php if($error = 'Ой, вам сюда нельзя!'): ?>
                <?php if((Auth::user()->role == 'admin') or Auth::user()->role == 'superadmin'): ?>
                    <a href="<?php echo e(url('/admin')); ?>"><button class="btn btn-primary">Назад! </button></a>
                <?php else: ?>
                    <a href="<?php echo e(url('/user')); ?>"><button class="btn btn-primary">Назад! </button></a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-primary">Назад! </button></a>
            <?php endif; ?>
        </div>
        <div class="col-md-5 col-12">
            <img src="img/Мем.png" alt="^.^" class="col-12">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/general/error.blade.php ENDPATH**/ ?>