<style>
    .btn-danger{
        margin-left: 10px;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-12">
            <form method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="file" class="btn" style="padding: 0; margin: 0;">Добавить новый список из таблицы Excel</label>
                <input accept="
                    application/vnd.ms-excel,
                    application/vnd.ms-office,
                    application/vnd-xls,
                    application/vnd.ms-excel,
                    application/msexcel,
                    application/x-msexcel,
                    application/x-ms-excel,
                    application/x-excel,
                    application/excel,
                    application/x-dos_ms_excel,
                    application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,
                    application/xls,
                    application/x-xls"
                       id = "file" type="file" name="file" placeholder="Подтверждение"><br>
                <input type="submit" value="Добавить">
            </form>
        </div>
        <div class="table-responsive">
        <form id="1" method="POST" action="/achievement_types/delete_selected"><?php echo csrf_field(); ?></form>
        <table class="table table-hover">
            <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Достижения<input type="submit" form="1" value="Удалить выбранные" class="btn btn-danger"><a href="/achievement_types/all/delete" class="btn btn-danger">Удалить все</a></th>
                <th scope="col">Баллы</th>
                <th scope="col"></th>
                <th scope="col"><a href='<?php echo e(url('/achievement_type/add')); ?>'><button class="btn btn-success">Добавить</button></a></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><input type="checkbox" form="1" name="<?php echo e($type->id); ?>"></td>
                    <td><?php echo e($type->category.', '.$type->type.', '.$type->stage.', '.$type->result); ?></td>
                    <td><?php echo e($type->score); ?></td>
                    <td><a href=<?php echo e(url('/achievement_type/'.$type->id.'/edit')); ?>> <button class="btn btn-warning">Изменить</button></a></td>
                    <td><a href=<?php echo e(url('/achievement_type/'.$type->id.'/delete')); ?>><button class="btn btn-danger">Удалить</button></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
    <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-primary" style="float: right">Назад</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/allAchievementTypes.blade.php ENDPATH**/ ?>