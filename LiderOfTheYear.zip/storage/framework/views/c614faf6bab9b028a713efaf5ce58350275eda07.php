<style>
    .btn-warning{
        margin-top: 20px;
    }
    
    .btn-primary{
        float:right;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
            <div class="col-md-10">
            <div class="card border-warning">
                <div class="card-header">Редактирование достижения<a href="/"><button class="btn btn-primary">Отмена</button></a></div>
                <div class="card-body">
                    <form method="POST" class="row col-12 justify-content-center" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <select name="category" onchange="changeStage(); disableForStage(); changeType(); disableForType(); changeCategory(); disableForCategory();">
                            <option disabled>Категория</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->category==$achievement->category): ?>
                                    <option selected><?php echo e($category->category); ?></option>
                                <?php else: ?>
                                    <option><?php echo e($category->category); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="type" onchange = "changeStage(); disableForStage(); changeType(); disableForType();">
                            <option disabled>Тип достижения</option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($type->type==$achievement->type): ?>
                                    <option selected><?php echo e($type->type); ?></option>
                                <?php else: ?>
                                    <option><?php echo e($type->type); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="text" name="name" placeholder="Название олимпиады" value="<?php echo e($achievement->name); ?>">
                        <input type="text" name="subject" placeholder="Предмет" value="<?php echo e($achievement->subject); ?>">
                        <select name="stage" onchange = "changeStage(); disableForStage();">
                            <option disabled>Этап</option>
                            <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($stage->stage==$achievement->stage): ?>
                                    <option selected><?php echo e($stage->stage); ?></option>
                                <?php else: ?>
                                    <option><?php echo e($stage->stage); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select> 
                        <select name="result">
                            <option disabled>Результат</option>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($result->result==$achievement->result): ?>
                                    <option selected><?php echo e($result->result); ?></option>
                                <?php else: ?>
                                    <option><?php echo e($result->result); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="file">Новое подтверждение </label> <input id="file" type="file" name="file">
                        <input type="submit" value="Изменить" class="btn btn-warning col-4">
                    </form>
                    <?php if($achievement->confirmation != ''): ?>
                        <a href="<?php echo e('/achievement/'.$achievement->id.'/download_confirmation'); ?>">Текущее подтверждение</a><br><br>
                    <?php else: ?>
                        <strong>На данный момент подтверждения нет</strong>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    let achievements = [];
    <?php $__currentLoopData = $achievement_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        achievements.push({category: "<?php echo e($achievement_type->category); ?>", type: "<?php echo e($achievement_type->type); ?>", stage: "<?php echo e($achievement_type->stage); ?>", result: "<?php echo e($achievement_type->result); ?>"});
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
<script src="/js/achievementSelection.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/user/edit_achievement.blade.php ENDPATH**/ ?>