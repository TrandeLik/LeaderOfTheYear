<style>
    .card{
        margin-bottom:20px;
    }
    .btn-primary{
        float:right;
    }
    .warning{
        color:firebrick;
    }
</style>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div id="app" class="col-md-10">
            <div class="card">
                <div class="card-header">Статистика</div>
                <div class="card-body">
                    <?php if(count($falseCategories)!=0): ?>
                        <p class="warning">
                            Ваши баллы за достижения в
                            <?php if(count($falseCategories)==1): ?>
                                категории
                            <?php else: ?>
                                категориях
                            <?php endif; ?>
                            <?php $__currentLoopData = $falseCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($category); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            превышают баллы за <?php echo e($mainCategory); ?>. Лишние баллы учтены не будут
                        </p>
                    <?php endif; ?>
                    <p>Сейчас у Вас <?php echo e($confirmedScore); ?> подтверждённых баллов<p>
                    <p>Если все Ваши достижения будут одобрены, Вы получите <?php echo e($totalScore); ?> баллов</p>
                        <?php if(($isStatisticsWorking) and (Auth::user()->confirmedScore()>=$minimalAllowedScore)): ?>
                            <p>Вы на <?php echo e($place); ?> месте</p>
                            <p>Вы входите в <?php echo e($percentage); ?> процентов лучших</p>
                        <?php elseif(Auth::user()->confirmedScore()<$minimalAllowedScore): ?>
                            <p class="warning">Ваших подтверждённых баллов недостаточно для участия в конкурсе. Количество баллов, которое вам ещё нужно набрать для попадания в рейтинг: <?php echo e($minimalAllowedScore - Auth::user()->confirmedScore()); ?></p>
                        <?php endif; ?>
                </div>
            </div>
            <div class="card border-primary">
                <div class="card-header">Мои олимпиады<a href="<?php echo e(url('/achievement/add/new')); ?>"><button class="btn btn-primary">Добавить</button></a></div>
                <div class="card-body">
                    <?php if($achievements != []): ?>
                        <achievement-table :achievements="<?php echo e(json_encode($achievements)); ?>" :is_admin="false" :section="'created'"></achievement-table>
                    <?php else: ?>
                        <p>Здесь пусто :)</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/user/index.blade.php ENDPATH**/ ?>