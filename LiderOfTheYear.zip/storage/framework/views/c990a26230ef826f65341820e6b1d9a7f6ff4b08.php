<?php $__env->startSection('content'); ?>

    <div id="app">
        <?php if($achievements !== []): ?>
            <achievement-table :achievements="<?php echo e(json_encode($achievements)); ?>" :is_admin="true"></achievement-table>
        <?php else: ?>
            <div class="alert alert-primary">
                <p>Здесь ничего нет :)</p>
            </div>
        <?php endif; ?>
    </div>
    <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-primary">Назад</button> </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/table.blade.php ENDPATH**/ ?>