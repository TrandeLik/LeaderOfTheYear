<style>
    .btn-primary{
        float:right;
    }
</style>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border-primary">
                <div class="card-header">Личные данные<a href="/profile/edit"><button class="btn btn-primary">Изменить</button></a></div>
                <div class="card-body">
                    <p>ФИО: <?php echo e($user->name); ?></p>
                    <p>E-mail: <?php echo e($user->email); ?></p>
                    <?php if($user->role=='student'): ?>
                        <p>Класс: <?php echo e($user->form); ?></p>
                    <?php endif; ?>
                    <a href="/profile/password_change"><button class="btn btn-warning">Изменить пароль</button></a>
                </div>
            </div>            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/general/profile.blade.php ENDPATH**/ ?>