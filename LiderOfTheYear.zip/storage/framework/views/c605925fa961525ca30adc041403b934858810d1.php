<style>
    .btn-success{
        margin-top:10px;
    }
</style>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card border-success">
                    <div class="card-header">Настройки</div>
                    <div class="card-body">
                        <form method="POST">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group row">
                                    <label for="<?php echo e($setting->id); ?>" class="col-md-4 col-form-label text-md-right"><?php echo e($setting->name); ?></label>
                                    <?php if($setting->type=='on/off'): ?>
                                        <?php if($setting->value=='on'): ?>
                                            <input type="checkbox" name="<?php echo e($setting->id); ?>" checked>
                                        <?php else: ?>
                                            <input type="checkbox" name="<?php echo e($setting->id); ?>">
                                        <?php endif; ?>
                                    <?php elseif($setting->type=='globalVariable'): ?>
                                        <?php if($setting->name != 'Главная категория'): ?>
                                            <input type="text" name="<?php echo e($setting->id); ?>" value="<?php echo e($setting->value); ?>">
                                        <?php else: ?>
                                            <select name="<?php echo e($setting->id); ?>">
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($setting->value == $category -> category): ?>
                                                        <option selected><?php echo e($category -> category); ?></option>
                                                    <?php else: ?>
                                                        <option><?php echo e($category -> category); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    <?php elseif($setting->type=='rulesSettings'): ?>
                                        <input name="<?php echo e($setting->id); ?>" onchange="document.getElementById('<?php echo e($setting->id); ?>').innerHTML = this.value;" type="range" value="<?php echo e($setting->value); ?>" step="5"/>
                                        <span id = "<?php echo e($setting->id); ?>" ><?php echo e($setting->value); ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <input type="submit" value="Сохранить" class="btn btn-success col-md-4 offset-md-4">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-primary">Назад</button> </a>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/settings.blade.php ENDPATH**/ ?>