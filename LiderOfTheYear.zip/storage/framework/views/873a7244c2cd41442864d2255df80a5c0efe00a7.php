<style>
    .btn-success{
        margin-top: 20px;
    }
    
    .btn-primary{
        float:right;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
            <div class="col-md-10">
            <div class="card border-success">
                <div class="card-header">Добавление достижения<a href="/"><button class="btn btn-primary">Отмена</button></a></div>
                <div class="card-body">
                    <form method="POST" class="row col-12 justify-content-center" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <select name="category" onchange="changeStage(); disableForStage(); changeType(); disableForType(); changeCategory(); disableForCategory();">
                            <option selected disabled>Категория</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($category->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="type" onchange = "changeStage(); disableForStage(); changeType(); disableForType();" disabled>
                            <option selected disabled>Тип</option>
                        </select>
                        <input type="text" name="name" placeholder="Название олимпиады">
                        <input type="text" name="subject" placeholder="Предмет">
                        <select name="stage" onchange = "changeStage(); disableForStage();" disabled>
                            <option selected disabled>Этап</option>
                        </select>
                        <select name="result" disabled>
                            <option selected disabled>Результат</option>
                        </select>
                        <label for="file" class="btn">Подтверждение</label>
                        <input id = "file" type="file" name="file" placeholder="Подтверждение"><br>
                        <input type="submit" value="Добавить" class="btn btn-success col-4">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    let achievements = [];
    <?php $__currentLoopData = $achievement_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        achievements.push({category: "<?php echo e($achievement_type->category); ?>", type: "<?php echo e($achievement_type->type); ?>", stage: "<?php echo e($achievement_type->stage); ?>", result: "<?php echo e($achievement_type->result); ?>"});
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
<script src="/js/achievementSelection.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/user/add_achievement.blade.php ENDPATH**/ ?>