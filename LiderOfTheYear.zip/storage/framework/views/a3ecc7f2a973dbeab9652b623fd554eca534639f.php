<style>
    .admin-comment{
        margin-right: auto;
        margin-left: 0;
        text-align: left;
    }

    .student-comment{
        margin-right: 0;
        margin-left: auto;
        text-align: right;
    }
</style>
<?php $__env->startSection('content'); ?>

    <div class="row pl-0">
        <div class="col-md-3">
            <h2>Достижения</h2>
                <div class='card'>
                    <div class='card-body'>
                        <ul>
                            <?php $__currentLoopData = $allTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($type -> category.', '.$type -> type.', '.$type -> stage); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <a href="<?php echo e(url('/achievement_types/all')); ?>">Все достижения</a><br>
                    </div>
              </div><br>
            <a href="<?php echo e(url('/achievement_type/add')); ?>">Добавить событие</a><br><br>
            <a href="<?php echo e(url('/achievement_types/download_file')); ?>">Текущий список достижений</a><br><br>
            <form method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div>
                        <div class="input-group">
                            <div class="custom-file">
                                <input accept=  "application/vnd.ms-excel,
                                                application/vnd.ms-office,
                                                application/vnd-xls,
                                                application/vnd.ms-excel,
                                                application/msexcel,
                                                application/x-msexcel,
                                                application/x-ms-excel,
                                                application/x-excel,
                                                application/excel,
                                                application/x-dos_ms_excel,
                                                application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,
                                                application/xls,
                                                application/x-xls" type="file" class="custom-file-input" id="file" name="file">
                                <label class="custom-file-label" for="file" data-browse="Обзор">Изменить список достижений</label>
                            </div>
                            <div class="input-group-prepend">
                                <input type="submit" class="btn btn-outline-secondary" value="Загузить">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-6" id="app">
            <h2>
                Заявки
                <a href="<?php echo e(url('achievements/all')); ?>"><button class="btn btn-success">Все достижения учеников</button></a>
            </h2>
            <?php if(count($sentAchievements) == 0): ?>
                <p>На данный момент заявок нет</p>
            <?php else: ?>
                <?php $__currentLoopData = $sentAchievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="card-body">
                            <h3 class="card-title">От пользователя <?php echo e($achievement -> user -> name); ?>, <?php echo e($achievement -> user -> form); ?></h3>
                            <p><?php echo e($achievement -> type.', '.$achievement -> name.', '.$achievement -> stage.', '.$achievement -> subject.', '.$achievement -> result); ?></p>
                            <a href="<?php echo e(url('/achievement/'.$achievement->id.'/download_confirmation')); ?>">Подтверждение</a><br>
                            <?php if(count($achievement->comments)!=0): ?>
                                <div class="show-comments-link">
                                    <a href = "" data-toggle="modal" data-target="#exampleModalLong">
                                        Посмотреть комментарии
                                    </a>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLongTitle">Комментарии</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                            <div class="modal-body">
                                                <div class="content">
                                                    <?php $__currentLoopData = $achievement->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($comment->author=='admin'): ?>
                                                            <div class="admin-comment">
                                                                <p>Admin</p>
                                                                <p><?php echo e($comment->text); ?></p>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="student-comment">
                                                                <p><?php echo e($comment->achievement->user->name); ?></p>
                                                                <p><?php echo e($comment->text); ?></p>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <br>
                            <a href="<?php echo e(url('/achievement/'. $achievement -> id . '/confirm')); ?>"><button class="btn btn-success">Одобрить</button> </a>
                            <reject-achievement :action-address="<?php echo e(json_encode('/achievement/' . $achievement->id . '/reject')); ?>" :id="<?php echo e($achievement->id); ?>"></reject-achievement>
                        </div><br>
                    </div><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/achievements/sent')); ?>">Все заявки</a>
            <?php endif; ?>
        </div>
        <div class="col-md-3">
            <h2>Участники</h2>
            <div class="card">
                <div class="card-body">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(url('/user/' . $student -> id . '/profile')); ?>"><?php echo e($student -> name . ', ' . $student -> form); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br>
                    <a href="<?php echo e(url('/users/all')); ?>">Все участники</a>
                </div>
            </div><br>
            <a href="<?php echo e(url('/users/banned')); ?>">Заблокированные пользователи</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/admin.blade.php ENDPATH**/ ?>