<?php $__env->startSection('content'); ?>
<div class="container">
    <table class="table table-hover">
        <thead>
            <tr>
            <th scope="col">№</th>
            <th scope="col">ФИО</th>
            <th scope="col">Баллы</th>
            </tr>
        </thead>
        <tbody>
            <?php for($i = count($leaders)-1; $i >= 0; $i--): ?>
                <tr>
                    <th scope="row"><?php echo e(count($leaders)-$i); ?></th>
                    <td><?php echo e(array_keys($leaders)[$i]); ?></td>
                    <td><?php echo e(array_values($leaders)[$i]); ?></td>
                </tr>
            <?php endfor; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/leaderboard.blade.php ENDPATH**/ ?>