<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h1>Заявки</h1>
            <?php if(count($sentAchievements) == 0): ?>
                <p>На данный момент заявок нет</p>
            <?php endif; ?>
            <?php $__currentLoopData = $sentAchievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">От пользователя <?php echo e($achievement -> user -> name); ?>, <?php echo e($achievement -> user -> form); ?></h3>
                        <p><?php echo e($achievement -> type.', '.$achievement -> name.', '.$achievement -> stage.', '.$achievement -> subject.', '.$achievement -> result); ?></p>
                        <a href="<?php echo e($achievement -> confirmation); ?>">Подтверждение</a><br><br>
                        <a href="<?php echo e(url('/achievement'. $achievement -> id . '/confirm')); ?>"><button class="btn btn-success">Одобрить</button> </a>
                        <a href="<?php echo e(url('/achievement'. $achievement -> id . '/reject')); ?>"><button class="btn btn-danger">Отклонить</button> </a>
                    </div><br>
                </div><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-2">
            <h1>Участники</h1>
            <div class="card">
                <div class="card-body">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(url('/user' . $student -> id . 'profile')); ?>"><?php echo e($student -> name . ', ' . $student -> form); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin.blade.php ENDPATH**/ ?>