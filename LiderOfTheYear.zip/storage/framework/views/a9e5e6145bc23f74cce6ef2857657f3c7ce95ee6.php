<style>
    .btn-primary{
        float:right;
    }
</style>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border-primary">
                <div class="card-header">Личные данные<a href="/profile"><button class="btn btn-primary">Отмена</button></a></div>
                <div class="card-body">
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <p>ФИО: <input type="text" value="<?php echo e($name); ?>" name="username" required></p>
                        <p>E-mail: <input type="text" value="<?php echo e($email); ?>" name="email" required></p>
                        <?php if($role=='student'): ?>
                            <p>
                                Класс: 
                                <select name="formNumber" required>
                                    <?php $__currentLoopData = $formNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($formNumber == $userFormNumber): ?>
                                            <option selected><?php echo e($formNumber); ?></option>
                                        <?php else: ?>
                                            <option><?php echo e($formNumber); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="formLetter" required>
                                    <?php $__currentLoopData = $formLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formLetter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($formLetter == $userFormLetter): ?>
                                            <option selected><?php echo e($formLetter); ?></option>
                                        <?php else: ?>
                                            <option><?php echo e($formLetter); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </p>
                        <?php endif; ?>
                        <input type="submit">
                    </form>
                </div>
            </div>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/general/editProfile.blade.php ENDPATH**/ ?>