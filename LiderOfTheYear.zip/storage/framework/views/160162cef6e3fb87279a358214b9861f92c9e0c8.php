<style>
    .btn-primary{
        float:right;
    }
</style>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border-primary">
                <div class="card-header">Изменение пароля<a href="/profile"><button class="btn btn-primary">Отмена</button></a></div>
                <div class="card-body">
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <p>Старый пароль: <input type="password" name="old"></p>
                        <p>Новый пароль: <input type="password" name="new"></p>
                        <p>Подтверждение пароля: <input type="password" name="confirm"></p>
                        <input type="submit">
                    </form>
                </div>
            </div>            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/general/change_password.blade.php ENDPATH**/ ?>