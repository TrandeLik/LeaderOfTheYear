<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
            <tr>
                <th scope="col">Пользователи</th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($user -> role == 'student'): ?>
                        <td scope="row"><a href="<?php echo e(url('/user/' . $user -> id . '/profile')); ?>"><?php echo e($user -> name.', '.$user -> form); ?> </a></td>
                        <td><a href=<?php echo e(url('/user/'.$user->id.'/ban')); ?>><button class="btn btn-danger"> Заблокировать </button></a></td>
                        <td><a href=<?php echo e(url('/user/'.$user->id.'/promote')); ?>><button class="btn btn-warning"> Назначить администратором </button></a></td>
                    <?php endif; ?>
                    <?php if($user -> role == 'admin'): ?>
                        <td scope="row"><strong>Администратор: </strong><?php echo e($user -> name); ?></td>
                        <td><a href=<?php echo e(url('/user/'.$user->id.'/ban')); ?>><button class="btn btn-danger"> Заблокировать </button></a></td>
                        <td><a href=<?php echo e(url('/user/'.$user->id.'/degrade')); ?>><button class="btn btn-warning"> Снять с должности администратора </button></a></td>
                    <?php endif; ?>
                    <?php if($user -> role == 'banned'): ?>
                        <td scope="row"><strong> Заблокирован: </strong><?php echo e($user -> name.', '.$user -> form); ?></td>
                        <td><a href=<?php echo e(url('/user/'.$user->id.'/unblock')); ?>><button class="btn btn-warning"> Разблокировать </button></a></td>
                        <td></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <a href="<?php echo e(url()->previous()); ?>"><button class="btn btn-primary" style="float: right">Назад</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/allUsers.blade.php ENDPATH**/ ?>