<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <a href="/leaderboard/export">Экспортировать в Excel</a>
    <table class="table table-hover">
        <thead>
            <tr>
            <th scope="col">Место</th>
            <th scope="col">ФИО</th>
            <th scope="col">Класс</th>
            <?php if($isScoreShouldBeShown): ?>
                <th scope="col">Баллы</th>
            <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $leaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class=<?php echo e(($leader->percentage()<=$awardedPercentage + $winnerPercentage) ? ($leader->percentage()<=$winnerPercentage) ? 'table-success' : 'table-warning' : ''); ?>>
                    <th scope="row"><?php echo e($leader->place()); ?></th>
                    <td><?php echo e($leader->name); ?></td>
                    <td><?php echo e($leader->form); ?></td>
                    <?php if($isScoreShouldBeShown): ?>
                        <td><?php echo e($leader->score); ?></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/general/leaderboard.blade.php ENDPATH**/ ?>