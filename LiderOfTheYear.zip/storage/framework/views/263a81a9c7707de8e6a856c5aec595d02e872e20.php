<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h1>Заблокированные пользователи</h1>
            <?php if(count($bannedUsers) == 0): ?>
                <p>Заблокированных пользователей нет</p>
            <?php endif; ?>
            <?php $__currentLoopData = $bannedUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-header"><?php echo e($user -> name . ', ' . $user -> form); ?></h3><br>
                        <p><?php echo e($user -> email); ?></p>
                        <a href="<?php echo e(url('/user/'.$user -> id.'/unblock')); ?>"><button class="btn btn-success">Разблокировать</button> </a>
                    </div><br>
                </div><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <a href="<?php echo e(url('/')); ?>"><button class="btn btn-primary" style="float: right">Назад</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/admin/bannedUsers.blade.php ENDPATH**/ ?>