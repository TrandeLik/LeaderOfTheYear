<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <h1 class="display-3">К сожалению, ваша учетная запись заблокирована</h1>
                <p class="lead">Если вы считаете, что блокировка произошла несправедливо, свяжитесь с администрацией</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dmitiy\Documents\GitHub\LiderOfTheYear\resources\views/general/alertForBannedUsers.blade.php ENDPATH**/ ?>